package br.com.fiap;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

import br.com.fiap.model.Produto;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class PrimaryController implements Initializable {
    @FXML private TextField txtNome;
    @FXML private ChoiceBox<String> choiceCategoria;
    @FXML private TextField txtPreco;
    @FXML private TextField txtDescricao;
    @FXML private ListView<Produto> listView;
    private boolean disponibilidade = false;
    @FXML private CheckBox checkDisponivel;

    private List<Produto> lista = new ArrayList<>();

    private List<Produto> listaInteira = new ArrayList<>();

    private List<Produto> listaDisponivel = new ArrayList<>();

    public void salvar(){

        String nome = txtNome.getText();
        String descricao = txtDescricao.getText();
        double preco = Double.valueOf(txtPreco.getText());
        String categoria= choiceCategoria.getValue();
        boolean disponivel = disponibilidade;
       
       
        var produto = new Produto(nome, preco, categoria, descricao, disponivel);
        
        if(disponibilidade ==true){
            listaDisponivel.add(produto);
            lista.add(produto);
            listaInteira.add(produto);
        }

        else{lista.add(produto);
            listaInteira.add(produto);}
        
        listView.getItems().add(produto);

        alerta();

        limparInformações();
       
    }


    public void tornarDisponivel(){

        disponibilidade = !disponibilidade;
        
    }


    public void ordernarDiponivel(){
        listView.getItems().clear();
        listView.getItems().addAll(listaDisponivel);
        
    }


    public void ordenarPorPreco(){
        Collections.sort(lista);
        listView.getItems().clear();
        listView.getItems().addAll(lista);
    }
    

    public void listaComum(){
        listView.getItems().clear();
        listView.getItems().addAll(listaInteira);
    }


    
    public void limparInformações(){
        txtNome.setText("");
        txtDescricao.setText("");
        choiceCategoria.setValue(null);
        txtPreco.setText("");
        checkDisponivel.setSelected(false);
        disponibilidade = false;
        
    }
    

    public void alerta(){
        Alert alerta = new Alert(AlertType.INFORMATION);
        alerta.setContentText("Produto cadastrado com sucesso");
        alerta.show();
    }
    

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        choiceCategoria.getItems().addAll(List.of("LANCHE", "BEBIDAS", "REFEIÇÃO"));
    }
}